"""Shared, import-safe helpers for Parts 2 and 4.

This module contains functions only. Importing it never loads data, trains a model,
prints results, or writes files.
"""
import numpy as np

FEATURES = [
    "customer_tenure_months",
    "complaint_count_90d",
    "discount_order_share",
    "avg_order_value_inr_hundreds",
    "loyalty_score",
    "cod_flag",
    "plus_member_flag",
]

def stratified_split(X, y, test_size=0.30, seed=42):
    rng = np.random.default_rng(seed)
    train_indices, test_indices = [], []
    for class_value in np.unique(y):
        indices = np.where(y == class_value)[0]
        rng.shuffle(indices)
        n_test = int(round(len(indices) * test_size))
        test_indices.extend(indices[:n_test])
        train_indices.extend(indices[n_test:])
    train_indices = np.asarray(train_indices, dtype=int)
    test_indices = np.asarray(test_indices, dtype=int)
    rng.shuffle(train_indices)
    rng.shuffle(test_indices)
    return X[train_indices], X[test_indices], y[train_indices], y[test_indices]

def sigmoid(z):
    z = np.clip(z, -500, 500)
    return 1.0 / (1.0 + np.exp(-z))

def binary_cross_entropy(y_true, probabilities):
    eps = 1e-15
    p = np.clip(probabilities, eps, 1 - eps)
    return -np.mean(y_true * np.log(p) + (1-y_true) * np.log(1-p))

def train_logistic_regression(X, y, learning_rate=0.1, iterations=1000):
    n_samples, n_features = X.shape
    weights = np.zeros(n_features)
    bias = 0.0
    losses = []
    for _ in range(iterations):
        probabilities = sigmoid(X @ weights + bias)
        losses.append(binary_cross_entropy(y, probabilities))
        dw = X.T @ (probabilities - y) / n_samples
        db = np.mean(probabilities - y)
        weights -= learning_rate * dw
        bias -= learning_rate * db
    return weights, bias, losses

def confusion_counts(y_true, y_pred):
    tp = int(np.sum((y_true == 1) & (y_pred == 1)))
    fp = int(np.sum((y_true == 0) & (y_pred == 1)))
    tn = int(np.sum((y_true == 0) & (y_pred == 0)))
    fn = int(np.sum((y_true == 1) & (y_pred == 0)))
    return tp, fp, tn, fn

def calculate_metrics(y_true, y_pred):
    tp, fp, tn, fn = confusion_counts(y_true, y_pred)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "TP": tp, "FP": fp, "TN": tn, "FN": fn,
        "Precision": precision, "Recall": recall, "F1": f1,
    }

def knn_probabilities(X_train, y_train, X_query, k):
    probabilities = []
    for point in X_query:
        distances = np.sqrt(np.sum((X_train - point) ** 2, axis=1))
        nearest = np.argsort(distances)[:k]
        probabilities.append(np.mean(y_train[nearest]))
    return np.asarray(probabilities)

def knn_predict(X_train, y_train, X_query, k):
    """Part 2-compatible hard-label KNN prediction."""
    p = knn_probabilities(X_train, y_train, X_query, k)
    return (p > 0.5).astype(int)

def make_stratified_folds(y, n_folds=5, seed=42):
    rng = np.random.default_rng(seed)
    folds = [[] for _ in range(n_folds)]
    for class_value in np.unique(y):
        indices = np.where(y == class_value)[0]
        rng.shuffle(indices)
        for i, index in enumerate(indices):
            folds[i % n_folds].append(index)
    return [np.asarray(fold, dtype=int) for fold in folds]

def cross_validate_knn(X, y, k_values):
    folds = make_stratified_folds(y, n_folds=5, seed=42)
    results = []
    for k in k_values:
        fold_f1 = []
        for i in range(5):
            val_idx = folds[i]
            train_idx = np.concatenate([folds[j] for j in range(5) if j != i])
            p = knn_probabilities(X[train_idx], y[train_idx], X[val_idx], k)
            pred = (p >= ((k + 1) / 2) / k).astype(int)
            fold_f1.append(calculate_metrics(y[val_idx], pred)["F1"])
        results.append({"K": int(k), "Mean_F1": float(np.mean(fold_f1)),
                        "Std_F1": float(np.std(fold_f1))})
    return results

def get_oof_logistic_probabilities(X, y, learning_rate=0.1, iterations=1000):
    folds = make_stratified_folds(y, n_folds=5, seed=42)
    oof = np.zeros(len(y))
    for i in range(5):
        val_idx = folds[i]
        train_idx = np.concatenate([folds[j] for j in range(5) if j != i])
        w, b, _ = train_logistic_regression(
            X[train_idx], y[train_idx], learning_rate, iterations
        )
        oof[val_idx] = sigmoid(X[val_idx] @ w + b)
    return oof

def financial_cost(fp, fn):
    return 50 * fp + 400 * fn
