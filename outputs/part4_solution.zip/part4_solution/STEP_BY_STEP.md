# Step-by-step run guide

1. Keep `records.csv` in this folder. The script uses the seven Part 2 features in the same order and the same stratified 70/30 split (seed 42).
2. `model_helpers.py` contains shared functions only. It has no top-level data loading, training, printing, or file-writing side effects.
3. In Part 2, import shared functions from `model_helpers.py` and remove the duplicate local definitions. Example:
   ```python
   from model_helpers import (
       FEATURES, stratified_split, sigmoid, binary_cross_entropy,
       train_logistic_regression, confusion_counts, calculate_metrics,
       knn_predict, make_stratified_folds, cross_validate_knn,
       get_oof_logistic_probabilities, financial_cost,
   )
   ```
   Use `X = df[FEATURES].to_numpy(dtype=float)`. The helper's `stratified_split` preserves Part 2's four-return-value interface.
4. Run Part 4:
   ```bash
   python part4.py
   ```
5. Check the checkpoints: `root_entropy` should be 0.7462 and `round1_error` should be 0.2500. The script writes the four requested CSVs and `part4_results.txt` under `outputs/`.
6. The K value is selected by five-fold CV on the 560 training rows only. The test set is used only for the final Part 4 voting metrics.
7. The Task 2.8 logistic cost comparator is recalculated from training-only out-of-fold probabilities. Its selected threshold is 0.09 and its test cost is ₹6,300. The Part 4 model comparisons themselves use the requested 0.30 threshold.

## Notes about the uploaded Part 2 script

The uploaded script contains a bare, uncommented line `Implement Binary Cross-Entropy loss` and calls `financial_cost` without defining it. Those must be corrected for the original script to run. `model_helpers.py` supplies the shared functions, including `financial_cost`, and is safe to import. Keep the Part 2 execution under `if __name__ == "__main__":` if you intend to import the Part 2 module elsewhere.
