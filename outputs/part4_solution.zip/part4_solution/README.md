# Part 4 — Findings and model-choice memo

## Part 4 findings

### R4.1 — Purest split

The best split is **S4: X1 ≤ 24**, with information gain **0.127488** and Gini gain **0.060749**, the largest values among the four candidates. A tree grown until every leaf is pure can memorise noise and peculiarities in the training rows, so its test performance may be worse; a practical stopping rule is a maximum tree depth (`max_depth`) or a minimum number of samples per leaf.

### R4.2 — Voting comparison

I would ship the **stump** as the current structured-data candidate at probability threshold **0.30**. It achieved **F1 = 0.553846** and **recall = 0.705882** on the 240 test rows. Combining models did not help: hard voting had F1 **0.512397** and recall **0.607843**, while soft voting had F1 **0.492063** and recall **0.607843**. The stump's positive rates are **0.447236** for X1 ≤ 24 and **0.083102** for X1 > 24.

### R4.3 — AdaBoost

After round 1 normalisation, the two points misclassified by h1 (points 3 and 7) each have weight **0.25**, for a combined weight of **0.50**. Round 2 trusts h2 more because its weighted error is lower (**0.166667** versus **0.25**), giving h2 a larger alpha (**0.804719** versus **0.549306**).

### R4.4 — Neural-network architecture

**Model A, CNN option 2 output shapes and parameters**

| Layer | Output shape | Parameters |
|---|---:|---:|
| Input | 28 × 28 × 1 | 0 |
| Conv1 (5 × 5, 6 filters, padding 2) | 28 × 28 × 6 | 156 |
| ReLU1 | 28 × 28 × 6 | 0 |
| Max-pool1 (2 × 2, stride 2) | 14 × 14 × 6 | 0 |
| Conv2 (5 × 5, 16 filters, padding 0) | 10 × 10 × 16 | 2,416 |
| ReLU2 | 10 × 10 × 16 | 0 |
| Max-pool2 (2 × 2, stride 2) | 5 × 5 × 16 | 0 |
| Flatten | 400 | 0 |
| Dense1 (32 neurons) | 32 | 12,832 |
| Dense2 (10 classes) | 10 | 330 |

The MLP total is **13,002** parameters and the CNN total is **15,734**. For the 10-class image task, I would use **ReLU** in hidden layers and **softmax** in the output layer with **categorical cross-entropy** loss.

**Model B, RNN shapes**

- \(W_{xh}\): **128 × 64**
- \(W_{hh}\): **128 × 128**
- \(W_{hy}\): **16 × 128**
- \(b_h\): **128** parameters; \(b_y\): **16** parameters
- Total: **26,768** parameters.

The RNN parameter count does not grow with sequence length because the same weight matrices and biases are reused at every time step. A very deep plain network can suffer vanishing gradients, so gradients reaching early layers become too small to update them effectively; a skip connection provides a direct path for information and gradients to pass across layers.

For the 128 × 128 × 3 input comparison, the fully connected layer has **50,332,672** parameters, while the convolutional layer has **1,792**. Convolution scales better because each filter's small set of weights is shared across spatial positions rather than connecting every input pixel to every output neuron.

---

## Model-choice memo

**To: Head of the Retention Team**  
**Subject: Structured-data model recommendation**

I recommend piloting the one-question **stump** for churn screening, using a probability threshold of **0.30**. Its split is X1 ≤ 24; the training positive rates are 0.447236 on the yes side and 0.083102 on the no side. On the 240 test rows it achieved F1 **0.553846** and recall **0.705882**, slightly exceeding logistic regression's F1 of 0.541353 at the same threshold. Combining models did not improve results: hard-vote F1 was 0.512397 and soft-vote F1 was 0.492063.

For the required Task 2.8 comparator, logistic regression's training-CV-selected threshold was **0.09**, and its test cost was **₹6,300** under the ₹50-per-FP / ₹400-per-FN rule. The stump's cost was not computed under that cost rule, so it should not be assumed cheaper. This is a small, single split/test evaluation; the stump's simplicity may also miss interactions between customer features. Validate it on a later time-based holdout and calculate its business cost before full deployment.

**Model A and Model B are not worth building before the structured churn model is in production**, because image categorisation and review-topic classification are separate use cases rather than improvements to the current churn task.
